import UIKit

// Task 1 - Create a function which will extract number from  following string.
func extractNumberFromString(inputString: String) -> String {
    return inputString.replacingOccurrences(of: "[{([a-zA-z] )}]", with: "", options: .regularExpression)
}
print(extractNumberFromString(inputString: "My Wallet (SAR 1,685,633.00)"))


// Task 2 - Remove underscore from following String
func removeUnderscore(inputString: String) -> String {
    return inputString.replacingOccurrences(of: "_", with: " ")
}
print(removeUnderscore(inputString: "28_12_2024"))


// Task 3 - Remove Leading zero if it exist in following String
func removeLeadingZero(inputString: String) -> Any {
    return inputString.hasPrefix("0") ? inputString.dropFirst() : inputString
}
print(removeLeadingZero(inputString: "01 December 2022"))
